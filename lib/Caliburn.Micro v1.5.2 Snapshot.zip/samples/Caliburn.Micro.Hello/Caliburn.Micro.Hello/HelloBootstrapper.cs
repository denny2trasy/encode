﻿namespace Caliburn.Micro.Hello
{
    public class HelloBootstrapper : Bootstrapper<ShellViewModel> {}
}