﻿namespace Caliburn.Micro.SimpleMDI {
    public class AppBootstrapper : Bootstrapper<ShellViewModel> {}
}