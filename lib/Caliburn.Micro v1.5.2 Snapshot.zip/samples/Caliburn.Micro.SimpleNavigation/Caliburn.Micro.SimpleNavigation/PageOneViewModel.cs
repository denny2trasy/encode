﻿namespace Caliburn.Micro.SimpleNavigation {
    public class PageOneViewModel {}
}