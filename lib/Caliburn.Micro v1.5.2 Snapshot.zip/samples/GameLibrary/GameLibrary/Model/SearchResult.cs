﻿namespace GameLibrary.Model {
    using System;

    public class SearchResult {
        public Guid Id { get; set; }
        public string Title { get; set; }
    }
}