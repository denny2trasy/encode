namespace GameLibrary.Framework {
    using Caliburn.Micro;

    public interface IShell : IConductActiveItem {}
}