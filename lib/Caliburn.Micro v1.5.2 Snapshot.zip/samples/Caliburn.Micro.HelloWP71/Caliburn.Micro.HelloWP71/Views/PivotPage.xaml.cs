﻿namespace Caliburn.Micro.HelloWP71.Views {
    public partial class PivotPage {
        public PivotPage() {
            InitializeComponent();
        }
    }
}