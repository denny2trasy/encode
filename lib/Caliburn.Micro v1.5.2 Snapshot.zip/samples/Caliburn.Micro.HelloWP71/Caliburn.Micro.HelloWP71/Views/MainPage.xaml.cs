﻿namespace Caliburn.Micro.HelloWP71.Views {
    public partial class MainPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}