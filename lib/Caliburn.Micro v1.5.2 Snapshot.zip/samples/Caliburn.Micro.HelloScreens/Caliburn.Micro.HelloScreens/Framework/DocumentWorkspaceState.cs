namespace Caliburn.Micro.HelloScreens.Framework {
    public enum DocumentWorkspaceState {
        Master,
        Detail
    }
}