namespace Caliburn.Micro.ViewFirst {
    public interface IShell {}
}