﻿namespace Caliburn.Micro.ViewFirst {
    using System.Windows.Controls;

    public partial class ShellView : UserControl {
        public ShellView() {
            InitializeComponent();
        }
    }
}