﻿using System;

namespace Caliburn.Micro.WinRT.Sample.ViewModels
{
    public class SetupViewModel : ViewModelBase
    {
        public SetupViewModel(INavigationService navigationService)
            : base(navigationService)
        {
        }
    }
}
