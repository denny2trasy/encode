namespace Caliburn.Micro.HelloMef
{
    public interface IShell
    {
    }
}