﻿namespace Caliburn.Micro.HelloWindowManagerWP71 {
    using Microsoft.Phone.Controls;

    public partial class MainPage : PhoneApplicationPage {
        public MainPage() {
            InitializeComponent();
        }
    }
}