﻿namespace Caliburn.Micro.HelloWindowManagerWP71 {
    using System.Windows.Controls;

    public partial class DialogView : UserControl {
        public DialogView() {
            InitializeComponent();
        }
    }
}