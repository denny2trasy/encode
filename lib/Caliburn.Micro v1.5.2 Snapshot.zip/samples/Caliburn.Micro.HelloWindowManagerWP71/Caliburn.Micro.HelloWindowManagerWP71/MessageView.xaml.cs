﻿namespace Caliburn.Micro.HelloWindowManagerWP71 {
    using System.Windows.Controls;

    public partial class MessageView : UserControl {
        public MessageView() {
            InitializeComponent();
        }
    }
}