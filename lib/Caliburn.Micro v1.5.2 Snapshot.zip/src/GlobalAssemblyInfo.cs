﻿using System.Reflection;
using System.Resources;

[assembly: AssemblyProduct("Caliburn.Micro")]
[assembly: AssemblyCompany("Blue Spire Consulting, Inc.")]
[assembly: AssemblyCopyright("Copyright © 2010")]

[assembly: NeutralResourcesLanguage("en-US")]

[assembly: AssemblyVersion("1.5.2")]
[assembly: AssemblyFileVersion("1.5.2")]
