﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Caliburn.Micro.PackageBuilder")]
[assembly: AssemblyDescription("")]

[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: Guid("a05b2f5a-b9d7-4afc-9c63-6cf297b233d1")]
